/**
 * Event classes and listener interfaces, used to provide a change notification mechanism on graph
 * modification events.
 */
package org.jgrapht.event;
